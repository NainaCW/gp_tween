# SPDX-FileCopyrightText: 2025 cosmosmythos
#
# SPDX-License-Identifier: GPL-3.0-or-later

import os
import bpy
from bpy.app.handlers import persistent
from bpy.props import EnumProperty, FloatProperty, StringProperty
from bpy.types import PropertyGroup, AddonPreferences


class EaseTypeProperties(PropertyGroup):
    easing_type: EnumProperty(
        name="Easing Type",
        description="Select the easing type",
        items=[
            ('0', "Linear", "Linear"),
            ('1', "Ease Out", "Ease out"),
            ('2', "Ease In", "Ease in"),
        ],
        default='0'
    )

    linearize_smooth: FloatProperty(
        name="Linearize/Smooth",
        description="Blend between linear and eased behavior",
        min=0.0,
        max=1.0,
        default=0.5
    )

def append_node_group_from_file(filepath, node_group_name):
    """
    Appends a node group from the specified .blend file if it doesn't already exist.
    """
    if node_group_name not in bpy.data.node_groups:
        bpy.ops.wm.append(
            filepath=os.path.join(filepath, "NodeTree", node_group_name),
            directory=os.path.join(filepath, "NodeTree"),
            filename=node_group_name
        )


class GPTweenDriverSetup:
    @staticmethod
    def has_drivers(modifier):
        """Check if the modifier already has proper drivers set up"""
        easetype_node = modifier.node_group.nodes.get('EaseType')
        linearize_node = modifier.node_group.nodes.get('Linearize')
        
        if not easetype_node or not linearize_node:
            return False
            
        try:
            ease_driver = easetype_node.outputs[0].driver_get()
            linearize_driver = linearize_node.outputs[0].driver_get()
            
            if not ease_driver or not linearize_driver:
                return False
                
            if (ease_driver.variables.get("easing_type") and 
                linearize_driver.variables.get("linearize_smooth")):
                return True
        except:
            return False
            
        return False

    @staticmethod
    def setup_drivers(modifier):
        """Set up drivers for the modifier nodes"""
        easetype_node = modifier.node_group.nodes['EaseType']
        ease_driver = easetype_node.outputs[0].driver_add("default_value").driver
        ease_driver.type = 'AVERAGE'
        
        ease_var = ease_driver.variables.new()
        ease_var.name = "easing_type"
        ease_var.targets[0].id_type = 'SCENE'
        ease_var.targets[0].id = bpy.context.scene
        ease_var.targets[0].data_path = 'ease_type_props.easing_type'

        linearize_node = modifier.node_group.nodes['Linearize']
        linearize_driver = linearize_node.outputs[0].driver_add("default_value").driver
        linearize_driver.type = 'AVERAGE'
        
        linearize_var = linearize_driver.variables.new()
        linearize_var.name = "linearize_smooth"
        linearize_var.targets[0].id_type = 'SCENE'
        linearize_var.targets[0].id = bpy.context.scene
        linearize_var.targets[0].data_path = 'ease_type_props.linearize_smooth'


class GP_AddTweenModifier(bpy.types.Operator):
    bl_idname = "gpencil.add_tween_modifier"
    bl_label = "Add GP Tween Modifier"
    bl_description = "Adds a GP Tween modifier to the selected Grease Pencil object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                context.active_object.type == 'GREASEPENCIL')

    def execute(self, context):

        original_gp = context.active_object

        bpy.ops.grease_pencil.layer_lock_all(lock=False)

        # Check if gp_object already has tween modifier or only one layer
        has_tween_modifier = "GP Tween (c)" in original_gp.modifiers
        has_single_layer = len(original_gp.data.layers) == 1

        if has_tween_modifier or has_single_layer:
            target_gp = original_gp
        else:
              
            bpy.ops.object.duplicate_move()
            target_gp = context.active_object

            if target_gp:
                layers = target_gp.data.layers
                active_layer = layers.active

                for layer in layers[:]:
                    if layer != active_layer:
                        layers.remove(layer)

        bpy.context.scene.frame_start = 0
        

        filepath = os.path.join(os.path.dirname(__file__), "GP Tween (c).blend")
        node_group_name = "GP Tween (c)"
        
        try:
            append_node_group_from_file(filepath, node_group_name)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to append node group: {e}")
            return {'CANCELLED'}
        
        if "GP Tween (c)" not in target_gp.modifiers:
            modifier = target_gp.modifiers.new(name="GP Tween (c)", type='NODES')
            modifier.node_group = bpy.data.node_groups.get(node_group_name)   
            GPTweenDriverSetup.setup_drivers(modifier)
        else:
            modifier = target_gp.modifiers["GP Tween (c)"]
            if not GPTweenDriverSetup.has_drivers(modifier):
                GPTweenDriverSetup.setup_drivers(modifier)

        # Handle baking
        s_uid = target_gp.id_data.session_uid
        cook_id1 = None
        cook_id2 = None
        cook_id3 = None

        for bake in modifier.bakes:
            if bake.node.name == "Frames Calculation":
                cook_id1 = bake.bake_id
                bake.bake_mode = 'ANIMATION'
            elif bake.node.name == "Frames All":
                cook_id2 = bake.bake_id
            elif bake.node.name == "Tweened":
                cook_id3 = bake.bake_id
                bake.bake_mode = 'ANIMATION'

        if cook_id1 is not None and cook_id2 is not None and cook_id3 is not None:
            # First Bake (Frames Calculation)
            bpy.ops.object.geometry_node_bake_single(
                session_uid=s_uid,
                modifier_name="GP Tween (c)",
                bake_id=cook_id1
            )
            
            bpy.ops.screen.frame_jump(end=True)

            bpy.ops.object.geometry_node_bake_single(
                session_uid=s_uid,
                modifier_name="GP Tween (c)",
                bake_id=cook_id2
            )

            bpy.ops.object.geometry_node_bake_single(
                session_uid=s_uid,
                modifier_name="GP Tween (c)",
                bake_id=cook_id3
            )

        bpy.ops.screen.frame_jump(end=False)
        bpy.ops.screen.animation_play()
           
        return {'FINISHED'}


class GP_BakeTween(bpy.types.Operator):
    bl_idname = "gpencil.bake_tween"
    bl_label = "Bake"
    bl_description = "Bake the tweened strokes into a new object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT' and
                context.active_object and
                context.active_object.type == 'GREASEPENCIL' and
                "GP Tween (c)" in context.active_object.modifiers)

    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'GREASEPENCIL']
        active_object = context.active_object

        if any("_Tweened" in layer.name for layer in active_object.data.layers):
            self.report({'ERROR'}, "Object already contains Baked Inbetweens")
            return {'CANCELLED'}

        layer_names = {obj.name: [layer.name for layer in obj.data.layers] for obj in selected_objects}
        bpy.context.scene.frame_start = 0
        bpy.context.scene.cursor.location = (0.0, 0.0, 0.0)
        bpy.ops.grease_pencil.bake_grease_pencil_animation()

        baked_object = bpy.context.object
        if not baked_object or baked_object.type != 'GREASEPENCIL':
            self.report({'ERROR'}, "Failed to bake the animation.")
            return {'CANCELLED'}

        # Rename layers
        for i, layer in enumerate(baked_object.data.layers):
            obj_index = i % len(selected_objects)
            layer_index = i // len(selected_objects)
            original_names = layer_names.get(selected_objects[obj_index].name, [])
            if layer_index < len(original_names):
                layer.name = f"{original_names[layer_index]}_Tweened"

        # Remove original objects properly
        for obj in selected_objects:
            bpy.data.objects.remove(obj, do_unlink=True)

        self.report({'INFO'}, "Bake Completed.")
        return {'FINISHED'}


class EASE_OT_RemoveKeyframes(bpy.types.Operator):
    bl_idname = "gpencil.remove_easing"
    bl_label = "Clear Easing"
    bl_description = "Remove all keyframes for the easing type property"
    
    def execute(self, context):
        path = 'ease_type_props.easing_type'
        action = context.scene.animation_data.action if context.scene.animation_data else None

        if action:
            fcurve = action.fcurves.find(path)
            if fcurve:
                action.fcurves.remove(fcurve)
                self.report({'INFO'}, "All keyframes removed")
            else:
                self.report({'INFO'}, "No keyframes found")
        else:
            self.report({'INFO'}, "No easing data to remove keyframes from")
        
        return {'FINISHED'}


class GP_TweenPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_gp_tween"
    bl_label = "GP Tween (c)"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GP Tween"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        props = context.scene.ease_type_props
        
        # Tween
        col = layout.column(align=True)
        row = col.row(align=True)
        row.operator("gpencil.add_tween_modifier", text='Tween | Update', icon='FILE_MOVIE')
        
        # Bake
        col.separator()
        row = col.row(align=True)
        row.operator("gpencil.bake_tween", text='Bake', icon='OUTLINER_OB_GROUP_INSTANCE')

        # Easing
        col.separator()
        layout.prop(props, "easing_type")
        layout.prop(props, "linearize_smooth", slider=True)
        layout.operator("gpencil.remove_easing", text="Clear Easing")


panel_classes = [GP_TweenPanel]
def update_sidebar_category(self, context):
    for cls in panel_classes: 
        try:
            bpy.utils.unregister_class(cls)  # Unregister the panel
        except:
            pass
        cls.bl_category = self.sidebar_category  # Update category
        bpy.utils.register_class(cls)  # Re-register the panel

class GPTweenPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    sidebar_category: bpy.props.StringProperty(
        name="Sidebar Category",
        description="Choose which sidebar category to place the GP Tween panel in",
        default="GP Tween",  # Comma added here
        update=update_sidebar_category  # Comma missing in your original code
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "sidebar_category")


classes = (
    GPTweenPreferences,
    EaseTypeProperties,
    GP_AddTweenModifier,
    GP_BakeTween,
    GP_TweenPanel,
    EASE_OT_RemoveKeyframes,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.ease_type_props = bpy.props.PointerProperty(type=EaseTypeProperties)
    
    prefs = bpy.context.preferences.addons[__package__].preferences
    GP_TweenPanel.bl_category = prefs.sidebar_category

def unregister():
    if hasattr(bpy.types.Scene, 'ease_type_props'):
        del bpy.types.Scene.ease_type_props

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()